package com.huangbin.smartcommunityelderlycare.dto;

import lombok.Data;

@Data
public class LoginDTO {
    private String phone;
    private String password;
}